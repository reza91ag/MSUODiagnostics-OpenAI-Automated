EntryFlow mobile layout, adaptive email color, and desktop Sign Out placement
Only main.dart.js is replaced. No Flutter rebuild or IDE is required.
Before applying, snapshot the exact deployed frontend directory on its host.
Only apply if the deployed main.dart.js SHA-256 matches the original hash below.
Stage the patched file next to the deployed file and swap it in, keeping the
original for immediate rollback. Invalidate cached main.dart.js if applicable.
Verify signed-in mobile flows against a dedicated test account and compare
desktop before considering the deployment complete. To roll back, restore the
original main.dart.js and invalidate the same cache entry.

Expected original main.dart.js SHA-256:
35f6a7317aab9d74e3165955f9d92de4fb61b89e14bf116d5760582c79764d09
